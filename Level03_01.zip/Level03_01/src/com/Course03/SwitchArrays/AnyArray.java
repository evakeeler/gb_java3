package com.Course03.SwitchArrays;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AnyArray<Typ> {

    public Typ[] anyArray;

    public AnyArray(Typ[] t) {
        anyArray = t;
    }

    public Typ[] ChangePlaces(Typ[] array, int first, int second){
        Typ tmp = array[first];
        anyArray[first] = array[second];
        anyArray[second] = tmp;

        //ArrayList<?> arr = new ArrayList<Typ[]>(array) ;
        return anyArray;
    }

//    public ArrayList massiveToArray(Typ[] array){
//        ArrayList<Typ> list = (ArrayList<Typ>) Arrays.asList(array);
//        System.out.println(list);
//        return list;
//    }


//    public Typ[] ChangePlaces(ArrayList<?> array, int first, int second){
//        //Typ tmp = array[first];
//        //anyArray[first] = array[second];
//        //anyArray[second] = tmp;
//
//        return anyArray;
//    }


    public void printArray(){
        for (int i = 0; i <anyArray.length ; i++) {
            System.out.println(anyArray[i].toString());
        }
    }

}
