package com.Course03.SwitchArrays;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        Integer inums[] = {1, 2, 3, 4, 5};
        String inum[] = {"1", "2", "3", "4", "5"};

        ArrayList<Integer> inta = new ArrayList<Integer>();
        inta.add(0,0);
        inta.add(1,1);
        inta.add(2,2);
        inta.add(3,3);
        inta.add(4,4);
        inta.add(5,5);
        //--------
//        AnyArray<Integer> iob = new AnyArray<Integer>(inums);
//        iob.ChangePlaces(inums,1,2);
        //-----------

//        --------
        AnyArray<String> iob = new AnyArray<String>(inum);
        iob.ChangePlaces(inum,1,2);
//        --------


//        AnyArray<Integer> iob = new AnyArray<Integer>(inta);
//        iob.ChangePlaces(inta,1,2);

        //============ convert array to ArrayList
        List<String> listOfStrings = new ArrayList<String>();
        Collections.addAll(listOfStrings, inum);
        listOfStrings.add("99");
        System.out.println(listOfStrings.getClass().getName());
        for (String str : listOfStrings) {
            System.out.println("-- " + str);
        }
        //===========

        //System.out.println(iob.massiveToArray(inum));
        iob.printArray();
    }

}
