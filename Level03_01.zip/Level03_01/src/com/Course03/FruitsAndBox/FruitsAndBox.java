package com.Course03.FruitsAndBox;

public class FruitsAndBox {
    public static void main(String[] args) {
        Fruit.Orange or = new Fruit.Orange(1.0);
        Box<Fruit.Orange> orangeBox = new Box<Fruit.Orange>(or);

        //for (int i = 0; i <4 ; i++) {
            //orangeBox.addFruit(or);
        //}

        //orangeBox.getWeight();
        //orangeBox.boxInfo();



        //Fruit.Apple app = new Fruit.Apple(1.0);
        //Box<Fruit.Apple> box = new Box<Fruit.Apple>(Fruit.Apple(1.0));
    }

}
