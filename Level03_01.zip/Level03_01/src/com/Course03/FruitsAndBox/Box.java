package com.Course03.FruitsAndBox;

import java.util.ArrayList;
import java.util.List;

public class Box<T> {
    private ArrayList container;
    private T fruit;

    public Box(T f) {
        this.fruit = f;
    }


    public void getWeight(){

        for (Object o: container) {
            System.out.println(o.getClass().getName());
        }
    }

    public void addFruit(T f){
        container.add(f);
    }

    public void boxInfo(){
        for (Object o: container) {
            System.out.println(o);
        }
    }

    public boolean Compare(Box b){

        return true;
    }

}
