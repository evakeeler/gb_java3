package com.Course03.FruitsAndBox;

import java.util.ArrayList;

public class Fruit {



    public class Apple extends Fruit{
        double weight;

        public Apple(double weight) {
            this.weight = weight;
        }
    }

    public static class Orange extends Fruit{
        double weight;


        public Orange(double weight) {
            this.weight = weight;
        }

        private double getWeight (){
            return weight;
        }
    }



}
