import com.Level03.Main;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;

import java.sql.*;
import java.util.Arrays;
import java.util.Collection;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(Parameterized.class)
public class TestingSQL extends Assert{
    @Parameterized.Parameters
    public static Collection<Object[]> dataSQL() {
        Object[][] values = {
                {"Крапивка,67", "Шевченко,98"},
                {"Соловьев,12", "Поттер,70"},
                {"Головьев,82", "Громов,80"}
//                {new String[]{"Крапивка,67"}, new String[]{"Шевченко,98"}},
//                {new String[]{"Соловьев,12"}, new String[]{"Поттер,70"},
//                {new String[]{"Головьев,82"}, new String[]{"Громов,80"}}
        };
        return Arrays.asList(values);
    }
    private String[] entryData, expected;

    private static Connection connection;
    private static Statement stmt;
    Main mains;

    public TestingSQL( String entryData, String expected ){
        String[] tokensED = entryData.split(",");
        String[] tokensEXP = expected.split(",");
        String[] arrED = new String[tokensED.length];
        String[] arrEXP = new String[tokensEXP.length];
        //System.out.println(tokensED.length);
        //System.out.println(tokensEXP.length);
        for (int i = 0; i <tokensED.length ; i++) {
            arrED[i]= tokensED[i];
        }
        for (int i = 0; i <tokensEXP.length ; i++) {
            arrEXP[i]= tokensEXP[i];
        }
        this.entryData = arrED;
        this.expected = arrEXP;
    }

    @Before
    public void init(){
        mains = new Main();
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:Students.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @Test
    public void isEntryAddedToSQLBase(){
        try {
            String query = "INSERT INTO Студенты (Фамилия, Балл) VALUES (?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, entryData[0]);
            ps.setInt(2, Integer.parseInt(entryData[1]));
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            mains.sqlBaseConnect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        Assert.assertEquals( entryData[1],mains.sqlBaseGetEntry(entryData[0]));
        try {
            stmt.execute("DELETE FROM Студенты WHERE Фамилия='"+entryData[0]+"';");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //mains.sqlBaseDisconnect();
    }

    @Test
    public void isEntryCanRead(){
        Assert.assertEquals(expected[1], mains.sqlBaseGetEntry(expected[0]));
    }

    @After
    public void finaly(){
        try {
            TestingSQL.connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}