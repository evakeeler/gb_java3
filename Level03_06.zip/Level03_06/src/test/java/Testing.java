
import com.Level03.Main;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;

import java.lang.reflect.Array;
import java.lang.reflect.Parameter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(Parameterized.class)
public class Testing extends Assert{
    @Parameterized.Parameters

    public static Collection<Object[]> data() {
//        Object[][] values = {
//                { 0, 10.0, false },
//                { 1, 16.0, false },
//                { 17, 17.0, true }
//        };
        Object[][] values = {
                { "6,5,3,0,4,9,6,5,3,0", "9,6,5,3,0"},
                { "6,5,4,0,2,7,9,7,1,2", "0,2,7,9,7,1,2" },
                { "6,5,4,0,2,7,9,7,1,2", "6,5,0,2,7,9,7,1,2" }
        };
        return Arrays.asList(values);
    }



//    public static Collection<Object[]> testData(){
////        return Arrays.asList(new Object[][]{
////                {0,0,0},{0,0,0}
////        });
//        int[] a = {4, 9, 6, 5, 3, 0};
//        return Arrays.asList(new Object[][][]{
//                {4, 9, 6, 5, 3, 0},
//                {6, 5, 3, 0, 4, 9, 6, 5, 3, 0},
//                {6, 5, 3, 0, 4, 9, 6, 5, 3, 0}
//        });
//    }
    //Thread.currentThread().getStackTrace()[1].getMethodName()
//    -----------------
//    private int[] entryData;
//    private int[] expected;
//
////    public Testing( int[] entryData, int[] expected ){
////        this.entryData = entryData;
////        this.expected = expected;
////    }
//    -------------------
    int[] entryData, expected;
    private static Connection connection;
    private static Statement stmt;

public Testing( String entryData, String expected ){
    String[] tokensED = entryData.split(",");
    String[] tokensEXP = expected.split(",");
    int[] arrED = new int[tokensED.length];
    int[] arrEXP = new int[tokensEXP.length];
    System.out.println(tokensED.length);
    System.out.println(tokensEXP.length);
    for (int i = 0; i <tokensED.length ; i++) {
        arrED[i]= Integer.parseInt(tokensED[i]);
    }
    for (int i = 0; i <tokensEXP.length ; i++) {
        arrEXP[i]= Integer.parseInt(tokensEXP[i]);
    }
    this.entryData = arrED;
    this.expected = arrEXP;
}


//      public  static ArrayList<Object[][]> testData{
//        return ArrayList<>(new Object[][]{
//                {4, 9, 6, 5, 3, 0},
//                {6, 5, 3, 0, 4, 9, 6, 5, 3, 0}
//        });
//    }


    Main mains;

    @Before
    public void init(){
        mains = new Main();
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:Students.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @Test
    public void lastFrom4inArray() {
        Assert.assertArrayEquals(expected,mains.last4Array(entryData));
    }

    @Test
    public void isArrayHave1or4() {
        Assert.assertTrue("Arrey have 1 or 4",mains.array1And4(entryData));
    }

    @After
    public void finaly(){
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
