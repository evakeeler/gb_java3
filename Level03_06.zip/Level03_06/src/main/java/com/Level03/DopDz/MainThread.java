package com.Level03.DopDz;

import java.util.ArrayList;

public class MainThread extends Thread {
    public static final int SHIP_COUNT = 8;
    public static boolean transferStarted = false;
    private ArrayList<Vessels> ships;
    private static int smallShips, bigShips, averageShips;
    public static boolean foodTransfered = false, fuelTransfered = false, clothesTransfered = false;

    @Override
    public void run() {

        Road roadToDock = new Road(new Dock(0, new Food(0), new Fuel(0), new Clothes(0)),
                new Water(100), new Channel(60), new Water(40),
                new Dock(1, new Food(5900), new Fuel(8500), new Clothes(2700)));
        this.ships = new ArrayList<Vessels>();
        //генератор распределения случайного распределения короблей по размерам позже
        smallShips = 3;
        averageShips = 3;
        bigShips = 2;
        for (int i = 0; i < smallShips; i++) {
            ships.add(new ShipSmall(roadToDock, 20 + (int) (Math.random() * 10)));
        }
        for (int i = 0; i < averageShips; i++) {
            ships.add(new ShipAverage(roadToDock, 20 + (int) (Math.random() * 10)));
        }
        for (int i = 0; i < bigShips; i++) {
            ships.add(new ShipBig(roadToDock, 20 + (int) (Math.random() * 10)));
        }
        for (Vessels ves : ships) {
            new Thread(ves).start();
        }

    }
}
