package com.Level03.DopDz;

import java.util.ArrayList;
import java.util.Arrays;

public class Road {
    private ArrayList<Obstacles> stages;

    public ArrayList<Obstacles> getStages() {
        return stages;
    }

    public Road(Obstacles... stages) {
        this.stages = new ArrayList<>(Arrays.asList(stages));
    }
}
