package com.Level03.DopDz;

public abstract class Vessels implements Runnable{
    protected String shipID;
    protected int speed, maxCargoLoad, cargoLoad;
    protected static int SHIP_COUNT;
    protected Road road;
    protected String cargo;
    protected String shipType;
    protected int transferGoodsType;

    static {
        SHIP_COUNT = 0;
    }
    public String getShipID() {
        return shipID;
    }

    public String getShipType() {
        return shipType;
    }

    public int getSpeed() {
        return speed;
    }

}
