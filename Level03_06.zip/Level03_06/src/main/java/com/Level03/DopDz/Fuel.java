package com.Level03.DopDz;

public class Fuel extends Goods{
    public Fuel(int mass) {
        this.description = "мощное топливо";
        this.mass = mass;
        this.maxStorageCapacity = mass;
        this.goodsType = 2;
    }
}
