package com.Level03.DopDz;

import java.util.ArrayList;
import java.util.Arrays;

public class Dock extends Obstacles {
    private int isLoadingCargo;
    private ArrayList<Goods> goods;

    public Dock(int isLoadingCargo, Goods... goods) {
        this.length = 0;
        this.description = "Работы в финальном доке по погрузке и разгрузке ";
        this.goods = new ArrayList<>(Arrays.asList(goods));
        this.isLoadingCargo = isLoadingCargo;
    }

    public int getQuantityFood() {
        for (Goods g : goods) {
            if (g.goodsType == 1) {
                return g.mass;
            }
        }
        return 0;
    }

    public int getQuantityFuel() {
        for (Goods g : goods) {
            if (g.goodsType == 2) {
                return g.mass;
            }
        }
        return 0;
    }

    public int getQuantityClothes() {
        for (Goods g : goods) {
            if (g.goodsType == 3) {
                return g.mass;
            }
        }
        return 0;
    }

    @Override
    public void go(Vessels vessels) {
        //if (isLoadingCargo==1) {
        try {
            System.out.println(vessels.getShipID() + " начал этап: " + description);
            //погрузка или разгрузка
            Thread.sleep(length / vessels.getSpeed() * 1000);
            if (vessels.cargoLoad == 0) {
                // погрузка на пустое судно
                if (vessels.shipType.equals("маленький")) {
                    for (Goods g : goods) {
                        if (g.goodsType == vessels.transferGoodsType) {
                            while (vessels.cargoLoad < 500 && g.mass > 0) {
                                if (g.mass >= 100) {
                                    vessels.cargoLoad += 100;
                                    g.mass -= 100;
                                    Thread.sleep(1000);
                                    System.out.println(vessels.getShipID() + " погрузил партию " + g.getDescription());
                                }
                            }


                            break;
                        }
                    }
                } else if (vessels.shipType.equals("средний")) {
                    for (Goods g : goods) {
                        if (g.goodsType == vessels.transferGoodsType) {
                            while (vessels.cargoLoad < 500 && g.mass > 0) {
                                if (g.mass >= 100) {
                                    vessels.cargoLoad += 100;
                                    g.mass -= 100;
                                    Thread.sleep(1000);
                                    System.out.println(vessels.getShipID() + " погрузил партию " + g.getDescription());
                                }
                            }


                            break;
                        }
                    }
                } else if (vessels.shipType.equals("большой")) {
                    for (Goods g : goods) {
                        if (g.goodsType == vessels.transferGoodsType) {
                            while (vessels.cargoLoad < 500 && g.mass > 0) {
                                if (g.mass >= 100) {
                                    vessels.cargoLoad += 100;
                                    g.mass -= 100;
                                    Thread.sleep(1000);
                                    System.out.println(vessels.getShipID() + " погрузил партию " + g.getDescription());
                                }
                            }


                            break;
                        }
                    }
                }
            } else {
                // разгрузка
                //if (vessels.shipType.equals("маленький")) {
                    for (Goods g : goods) {
                        if (g.goodsType == vessels.transferGoodsType) {
                            while (vessels.cargoLoad != 0 && g.mass < g.maxStorageCapacity) {
                                vessels.cargoLoad -= 100;
                                g.mass += 100;
                                Thread.sleep(1000);
                                System.out.println(vessels.getShipID() + " разгрузил партию " + g.getDescription());
                            }
                            break;
                        }
                    }


            }

            System.out.println(vessels.getShipID() + " закончил этап: " + description);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }
}
