package com.Level03.DopDz;

import java.util.ArrayList;
import java.util.Arrays;

public class StartPointDock extends Obstacles{
    private int isLoadingCargo;
    private ArrayList<Goods> goods;

    public StartPointDock(int isLoadingCargo, Goods... goods) {
        this.length = 0;
        this.description = "Работы в стартовом доке по погрузке и разгрузке ";
        this.goods = new ArrayList<>(Arrays.asList(goods));
    }

    @Override
    public void go(Vessels vessels) {
        try {
            System.out.println(vessels.getShipID() + " начал этап: " + description);
            //погрузка или разгрузка
            Thread.sleep(length / vessels.getSpeed() * 1000);

            System.out.println(vessels.getShipID() + " закончил этап: " + description);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}