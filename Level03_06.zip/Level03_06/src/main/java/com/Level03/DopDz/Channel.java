package com.Level03.DopDz;

public class Channel extends Obstacles {
    public Channel(int length) {
        this.length = length;
        this.description = "Сквозь канал проплываем " + length + " метров";
    }

    @Override
    public void go(Vessels vessels) {
        try {
            System.out.println(vessels.getShipID() + " начал этап: " + description);
            Thread.sleep(length / vessels.getSpeed() * 1000);
            System.out.println(vessels.getShipID() + " закончил этап: " + description);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
