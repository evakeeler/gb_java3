package com.Level03.DopDz;

public class Clothes extends Goods{
    public Clothes(int mass) {
        this.description = "красивая одежда";
        this.mass = mass;
        this.maxStorageCapacity = mass;
        this.goodsType = 3;
    }
}
