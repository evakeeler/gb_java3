package com.Level03.DopDz;

public class Water extends Obstacles{
    public Water(int length) {
        this.length = length;
        this.description = "Плывем по воде " + length + " метров";
    }

    @Override
    public void go(Vessels vessels) {
        try {
            System.out.println(vessels.getShipID() + " начал этап: " + description);
            Thread.sleep(length / vessels.getSpeed() * 1000);
            System.out.println(vessels.getShipID() + " закончил этап: " + description);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
