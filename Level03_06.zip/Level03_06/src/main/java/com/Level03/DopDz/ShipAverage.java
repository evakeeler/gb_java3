package com.Level03.DopDz;

public class ShipAverage extends Vessels implements Runnable{
    public ShipAverage(Road road, int speed) {
        this.road = road;
        this.speed = speed;
        this.cargo = "Пусто";
        this.shipType = "средний";
        this.transferGoodsType = 3;
        this.cargoLoad = 0;
        this.maxCargoLoad = 500;
        SHIP_COUNT++;
        this.shipID = "Баржа #" + SHIP_COUNT + " №" + (int) (1 + Math.random() * 1001);
    }

    @Override
    public void run() {
        try {
            System.out.println(this.shipID + " готовится");
            Thread.sleep(500 + (int) (Math.random() * 800));
            System.out.println(this.shipID + " готов");
        } catch (Exception e) {
            e.printStackTrace();
        }

        while (MainThread.clothesTransfered==false) {
            for (int i = 0; i < road.getStages().size(); i++) {
                road.getStages().get(i).go(this);
            }
            for (int i = road.getStages().size() - 1; i >= 0; i--) {
                road.getStages().get(i).go(this);
            }
        }
    }
}
