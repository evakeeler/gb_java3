package com.Level03.DopDz;

public abstract class Goods {
    protected String description;
    protected int mass;
    protected int goodsType;
    protected int maxStorageCapacity;

    public String getDescription() {
        return description;
    }
}
