package com.Level03.DopDz;

public class Food extends Goods{
    public Food(int mass) {
        this.description = "вкусная еда";
        this.mass = mass;
        this.maxStorageCapacity = mass;
        this.goodsType = 1;
    }
}
