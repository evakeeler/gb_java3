package com.Level03.DopDz;

public class Main {
    public static void main(String[] args) {
        Thread mainThread = new MainThread();
        mainThread.start();
    }
}
