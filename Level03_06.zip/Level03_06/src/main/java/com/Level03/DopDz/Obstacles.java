package com.Level03.DopDz;

public abstract class Obstacles {
    protected int length;
    protected String description;

    public String getDescription() {
        return description;
    }

    public abstract void go(Vessels vessels);

}
