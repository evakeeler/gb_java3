package com.Level03;

import java.sql.*;
import java.util.Arrays;

public class Main {
    private static Connection connection;
    private static Statement stmt;

    public static void main(String[] args) {
        Main m = new Main();
        int[] array = {2, 5, 4, 5, 7, 9, 1, 0, 3, 5, 5, 47, 4, 9, 6, 5, 3, 0};
        int[] array2 = {9, 6, 5, 3, 0};
//        System.out.println(Arrays.toString(m.last4Array(array2)));
//        System.out.println(Arrays.toString(m.last4Array(array)));
//        System.out.println(m.array1And4(array));
//        System.out.println(m.array1And4(array2));
        try {
            m.sqlBaseConnect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(m.sqlBaseGetEntry("Поттер"));
        //m.sqlBaseAddEntry("Шевченко", 98);

        m.sqlBaseDisconnect();

    }

    public int[] last4Array(int[] arr) {
        int x = -1;
        int[] newArray = null;
        for (int i = arr.length-1; i >= 0; i--) {
            if (arr[i] == 4) {
                x = i;
                newArray = new int[arr.length - x-1];
                for (int j = 0; j < newArray.length; j++) {
                    newArray[j] = arr[x + j+1];
                }
                break;
            }

        }
        try {
            if (x == -1)
                throw new RuntimeException("В массиве нет ни одной 4");
        }catch (RuntimeException e){
            e.printStackTrace();
        }
        return newArray;
    }

    public boolean array1And4(int[] arr){
        for (int i = 0; i <arr.length ; i++) {
            if (arr[i] == 1 || arr[i]==4){
                return true;
            }
        }
        return false;
    }

    public void sqlBaseConnect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:Students.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void sqlBaseDisconnect(){
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void sqlBaseAddEntry(String family, int score){
        try {
            String query = "INSERT INTO Студенты (Фамилия, Балл) VALUES (?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, family);
            ps.setInt(2, score);
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void sqlBaseChangeEntry(String familyOld, int scoreOld,String familyNew, int scoreNew){
        try {
            String query = "UPDATE Студенты SET Фамилия='"+familyNew+"', Балл="+String.valueOf(scoreNew)+" WHERE Фамилия='"+familyOld+"' AND Балл="+String.valueOf(scoreOld)+";";
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String sqlBaseGetEntry(String family){
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM Студенты WHERE Фамилия = ?");
            ps.setString(1, family);
            ResultSet rs = ps.executeQuery();
            String score = rs.getString(3);
            return score;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void deleteEntry (String condition, String result){
        try {
            stmt.executeUpdate("DELETE FROM Студенты WHERE "+condition+"='"+result+"';");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
