package com.Level03;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.Level03.MFU.printerDevice;
import static com.Level03.MFU.scanerDevice;

public class MfuController {
    @FXML
    TextArea taPrint;

    @FXML
    TextArea taScan;

    @FXML
    Button bPrint;

    @FXML
    Button bScan;

    @FXML
    TextField tfScan;

    @FXML
    TextField tfPrint;


    static int pagesScan;

    public void printClick(){
        if (!tfPrint.getText().equals("")) {
            try {
                Thread prT = new Thread(new threadPrintFX(Integer.parseInt(tfPrint.getText())));
                prT.start();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    public void scanClick(){
        if (!tfScan.getText().equals("")) {
            try {
                Thread prS = new Thread(new threadScanFX(Integer.parseInt(tfScan.getText())));
                prS.start();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
//        pagesScan = Integer.parseInt(tfScan.getText());
//        ExecutorService pool = Executors.newFixedThreadPool(3);
//
//        Thread print = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                synchronized (printerDevice) {
//                    taPrint.setText(taPrint.getText()+"1 поток сканирует\nОтсканировано: ");
//                    System.out.println("1 поток сканирует");
//                    System.out.println("Отсканировано: ");
//                    for (int i = 1; i <= MfuController.pagesScan; i++) {
//                        System.out.print(" "+i+",");
//                        taPrint.setText(taPrint.getText()+" "+i+",");
//                        try {
//                            Thread.currentThread().sleep(400);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    taPrint.setText(taPrint.getText()+"\n");
//                }
//            }
//        });
//
//
//        Thread scan = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                synchronized (printerDevice) {
//                    taScan.setText(taScan.getText()+"1 поток сканирует\nОтсканировано: ");
//                    System.out.println("1 поток сканирует");
//                    System.out.println("Отсканировано: ");
//                    for (int i = 1; i <= MfuController.pagesScan; i++) {
//                        System.out.print(" "+i+",");
//                        taScan.setText(taScan.getText()+" "+i+",");
//                        try {
//                            Thread.currentThread().sleep(400);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    taScan.setText(taScan.getText()+"\n");
//                }
//            }
//        });
//        pool.submit(print);
//        pool.submit(scan);

    }

    private class threadPrintFX implements Runnable {
        int pages;

        public threadPrintFX(int Pages) {
            pages = Pages;
        }

        @Override
        public void run() {
            synchronized (printerDevice) {
                taPrint.setText(taPrint.getText()+"1 поток пишет\nОтпечатано: ");
                System.out.println("1 поток пишет");
                System.out.println("Отпечатано: ");
                for (int i = 1; i <=pages; i++) {
                    System.out.print(" "+i+",");
                    taPrint.setText(taPrint.getText()+" "+i+",");
                    try {
                        Thread.currentThread().sleep(400);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                taPrint.setText(taPrint.getText()+"\n");
            }
        }
    }

    private class threadScanFX implements Runnable {
        int pages;

        public threadScanFX(int Pages) {
            pages = Pages;
        }

        @Override
        public void run() {
            synchronized (scanerDevice) {
                taScan.setText(taScan.getText()+"1 поток сканирует\nОтсканировано: ");
                System.out.println("1 поток сканирует");
                System.out.println("Отсканировано: ");
                for (int i = 1; i <=pages; i++) {
                    System.out.print(" "+i+",");
                    taScan.setText(taScan.getText()+" "+i+",");
                    try {
                        Thread.currentThread().sleep(400);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                taScan.setText(taScan.getText()+"\n");
            }
        }
    }
}
