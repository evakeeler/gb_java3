package com.Level03;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MFU {
    static Object printerDevice = new Object();
    static Object scanerDevice = new Object();
    volatile int countPrint = 0;
    volatile int countScan = 0;
    ArrayList<String> al = new ArrayList<>();
    String command;

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        MFU mfuClass = new MFU();
        while (true) {
            try {
                mfuClass.command = br.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (mfuClass.command.startsWith("power off")) {
                System.out.println("Выключение МФУ");
                break;
            }

            if (mfuClass.command.startsWith("print ")) {
                String[] tokens = mfuClass.command.split(" ",3);
                mfuClass.print(Integer.parseInt(tokens[2]));
                mfuClass.scan(Integer.parseInt(tokens[2]));
                mfuClass.scan(Integer.parseInt(tokens[2])+5);
            }

            if (mfuClass.command.startsWith("scan ")) {
                String[] tokens = mfuClass.command.split(" ",3);
                mfuClass.scan(Integer.parseInt(tokens[2]));
            }

        }
    }

    public void print(int Pages){
        threadPrintScan tP = new threadPrintScan(Pages,printerDevice,"1 поток пишет" +
                "\nОтпечатано: ",400);
        tP.start();
    }

    public void scan(int Pages){
        threadPrintScan tS = new threadPrintScan(Pages,scanerDevice,"1 поток сканирует" +
                "\nОтсканировано: ",400);
        tS.start();
    }


    private class threadPrintScan extends Thread {
        int pages;
        Object sync;
        String msg;
        long delay;

        public threadPrintScan(int pages, Object sync, String msg,long delay) {
            this.pages = pages;
            this.sync = sync;
            this.msg = msg;
            this.delay = delay;
        }

        @Override
        public void run() {
            synchronized (sync) {
                System.out.println(msg);
                for (int i = 1; i <=pages; i++) {
                    System.out.print(" "+i+",");
                    try {
                        Thread.currentThread().sleep(delay);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println();
                sync.notifyAll();
            }
        }
    }

    private class threadScan extends Thread {
        int pages;

        public threadScan(int Pages) {
            pages = Pages;
        }

        @Override
        public void run() {
            synchronized (scanerDevice) {
                System.out.println("1 поток сканирует");
                System.out.println("Отсканировано: ");
                for (int i = 1; i <=pages; i++) {
                    System.out.print(" "+i+",");
                    try {
                        Thread.currentThread().sleep(400);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println();
            }
        }
    }


}
