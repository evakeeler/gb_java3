package com.Level03;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReadFile {

    public static void main(String[] args) {
        ExecutorService exec = Executors.newFixedThreadPool(4);

        for (int i = 0; i <10 ; i++) {
            exec.execute(new Runnable() {
                @Override
                public void run() {
                    Scanner sc=null;
                    try {
                        sc = new Scanner(new File("data/file1.txt"));
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                    while (sc.hasNext()){
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println(sc.nextLine());
                    }
                    sc.close();
                    exec.shutdown();
                }
            });
        }
    }



}
