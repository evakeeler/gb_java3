package com.Level03;

import java.io.*;
import java.util.ArrayList;

public class Main {
    volatile int flag = 1;
    volatile String word = "";

    static Object monitor = new Object();

    int readLines=10;
    volatile int lineCount=0;
    boolean endOfFile=false;
    ArrayList<String> al = new ArrayList<>();
    String separator = System.getProperty("line.separator");
    File fileForThreads = new File("data/out.txt");
    BufferedWriter wr;
    {
        try {
            wr = new BufferedWriter(new FileWriter(fileForThreads,true));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Main m = new Main();
        //---- Попеременное переключение потоков
        //m.abc();

        //---- Построчная запись в файл по блокам устанавливаемой
        // длинны readLines = 10 строк
        //m.readLinesFromFile();
        //m.threadsToFile();


    }

    public void abc() {
        Thread tA = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 1) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.print("A");
//                        if (word.length() < 14) {
//                            word = word + "A";
//                        } else {
//                            System.out.println("\nword=" + word + "A");
//                            System.exit(0);
//                        }
                        flag = 2;
                        Main.monitor.notifyAll();
                    }
                }

            }
        });

        Thread tB = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 2) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.print("B");
//                        if (word.length() < 14) {
//                            word = word + "B";
//                        } else {
//                            System.out.println("\nword=" + word + "B");
//                            System.exit(0);
//                        }
                        flag = 0;
                        Main.monitor.notifyAll();
                    }
                }
            }
        });

        Thread tC = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 0) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.print("C");
//                        if (word.length() < 14) {
//                            word = word + "C";
//                        } else {
//                            System.out.println("\nword=" + word + "C");
//                            System.exit(0);
//                        }
                        flag = 1;
                        Main.monitor.notifyAll();
                    }
                }
            }
        });
        tA.start();
        tB.start();
        tC.start();
    }

    public void readLinesFromFile() {
        try {
            File file = new File("data/master.txt");
            //создаем объект FileReader для объекта File
            FileReader fr = new FileReader(file);
            //создаем BufferedReader с существующего FileReader для построчного считывания
            BufferedReader reader = new BufferedReader(fr);
            // считаем сначала первую строку
            String line = reader.readLine();
            while (line != null) {
                al.add(line);
                //System.out.println(line);
                // считываем остальные строки в цикле
                line = reader.readLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeLinesToFile() {
        try {

            for (int i = 0; i < readLines ; i++) {
                wr.write(al.get(i)+separator);
            }
            wr.flush();
            wr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void threadsToFile(){

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < readLines; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 1) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.println("1 поток пишет");
                        try {
                            for (int x = lineCount; x < lineCount+readLines ; x++) {
                                if (x < al.size()) {
                                    wr.write(al.get(x) + separator);
                                } else {
                                    wr.flush();
                                    endOfFile = true;
                                    break;
                                }
                            }
                            lineCount=lineCount+readLines;
                            wr.flush();
                            if (endOfFile==true){
                                break;
                            }
                            Thread.currentThread().sleep(20);
                            //wr.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        flag = 2;
                        Main.monitor.notifyAll();
                    }
                }

            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < readLines; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 2) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.println("2 поток пишет");
                        try {
                            for (int x = lineCount; x < lineCount+readLines ; x++) {
                                if (x < al.size()) {
                                    wr.write(al.get(x) + separator);
                                } else {
                                    wr.flush();
                                    endOfFile = true;
                                    break;
                                }
                            }
                            lineCount=lineCount+readLines;
                            wr.flush();
                            if (endOfFile==true){
                                break;
                            }
                            Thread.currentThread().sleep(20);
                            //wr.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        flag = 0;
                        Main.monitor.notifyAll();
                    }
                }
            }
        });

        Thread t3 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < readLines; i++) {
                    synchronized (Main.monitor) {
                        while (flag != 0) {
                            try {
                                Main.monitor.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        System.out.println("3 поток пишет");
                        try {
                            for (int x = lineCount; x < lineCount+readLines ; x++) {
                                if (x < al.size()) {
                                    wr.write(al.get(x) + separator);
                                } else {
                                    wr.flush();
                                    endOfFile = true;
                                    break;
                                }
                            }
                            lineCount=lineCount+readLines;
                            wr.flush();
                            if (endOfFile==true){
                                break;
                            }
                            Thread.currentThread().sleep(20);
                            //wr.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        flag = 1;
                        Main.monitor.notifyAll();
                    }
                }
            }
        });
        t1.start();
        t2.start();
        t3.start();
    }
}
