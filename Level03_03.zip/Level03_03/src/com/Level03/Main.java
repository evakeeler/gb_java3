package com.Level03;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {
        //readFileByBite("files/dz1.txt");
        //readSeveralFiles("files/any.txt", "files/1.txt", "files/2.txt", "files/3.txt", "files/4.txt", "files/5.txt");
        //readFileByPage("files/master.txt",2);
        readFileByPage("files/anekdoti30.txt",350);
    }

    public static void readFileByBite(String name) {
        try (FileInputStream in = new FileInputStream("files/dz1.txt")) {
            byte[] arr = new byte[256];
            int x;
            while ((x = in.read(arr)) != -1) {
                System.out.println(new String(arr, 0, x));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void readSeveralFiles(String out, String... names) {
        ArrayList<InputStream> alist = new ArrayList<>();
        for (String n : names) {
            try {
                FileInputStream ins = new FileInputStream(n);
                alist.add(ins);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        long t1 = System.currentTimeMillis();
        SequenceInputStream in = new SequenceInputStream(Collections.enumeration(alist));
        BufferedInputStream bufIn = new BufferedInputStream(in);

        try (BufferedOutputStream bufOut = new BufferedOutputStream(new FileOutputStream(out))) {
            int x;
            while ((x = bufIn.read()) != -1) {
                bufOut.write(x);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(System.currentTimeMillis() - t1);
//-------------
//        try (FileOutputStream fOut = new FileOutputStream(out)) {
//            int x;
//            while ((x = in.read()) != -1) {
//                fOut.write(x);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//-------------
    }

    public static void readFileByPage (String name,long page){
        long t1 = System.currentTimeMillis();
        System.out.println("Страница --"+page+"--\n===============");
        try (FileInputStream in = new FileInputStream(name)) {
            byte[] arr = new byte[15000000];
            int x;
            while ((x = in.read(arr)) != -1) {
                System.out.println(new String(arr, (int)(page*1800), 1800));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("===============");
        System.out.println(System.currentTimeMillis() - t1);
    }

}
