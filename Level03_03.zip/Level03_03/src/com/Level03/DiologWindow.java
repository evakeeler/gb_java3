package com.Level03;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class DiologWindow extends JFrame {

    File[] file;

    public DiologWindow() {
        setBounds(0, 0, 500, 500);
        JFileChooser dialog = new JFileChooser();
        dialog.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        dialog.setApproveButtonText("Выбрать");
        dialog.setDialogTitle("Выберите файл для загрузки");
        dialog.setDialogType(JFileChooser.OPEN_DIALOG);
        dialog.setMultiSelectionEnabled(false);
        dialog.showOpenDialog(this);
        dialog.getName(new file1 = dialog.getSelectedFile);
        file = dialog.getSelectedFiles();
        setVisible(true);
    }
}
