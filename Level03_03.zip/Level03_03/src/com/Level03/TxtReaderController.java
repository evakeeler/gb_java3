package com.Level03;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import com.Level03.DiologWindow;

public class TxtReaderController {
    @FXML
    TextFlow textMain;

    @FXML
    Label labPage;

    @FXML
    TextField tfPage;

    @FXML
    Button bBackward, bForward;

    String txtFile;

    boolean isFileLoaded = false;

    public void toPage(){
        System.out.println("toPage");
        if (isFileLoaded){
            Main.readFileByPage(txtFile,Integer.parseInt(tfPage.getText()));
        }else {
            Text text1 = new Text("Текстовый файл не загружен!!! ");
            text1.setFill(Color.RED);
            text1.setFont(Font.font("Helvetica", FontPosture.ITALIC, 28));
            textMain.getChildren().add(text1);
        }

    }

    public void openTxtFile(){
        DiologWindow dw = new DiologWindow();
        //Main.readFileByPage(dw.file[0].getPath(),1);
        System.out.println(dw.file[0].getPath());
    }

}
