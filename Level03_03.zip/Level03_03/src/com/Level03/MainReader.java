package com.Level03;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class MainReader  extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("TxtReaderWindow.fxml"));
        primaryStage.setTitle("TxT-Reader");
        primaryStage.setScene(new Scene(root, 600, 820));
        primaryStage.show();
    }

}
