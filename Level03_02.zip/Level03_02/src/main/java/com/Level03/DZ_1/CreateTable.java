package com.Level03.DZ_1;

import java.sql.*;

public class CreateTable {
    public static Connection connection;
    public static Statement stmt;

    public static void main(String[] args) {
        try {
            connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        addTable("Products");
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:Level03Products.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void addTable(String tableName) {
        try {
            String query = "CREATE TABLE IF NOT EXISTS " + tableName +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                    "prodid TEXT UNIQUE NOT NULL," +
                    "title TEXT NOT NULL," +
                    "cost INTEGER NOT NULL);";
            stmt.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public static void addTable(String tableName) {
//        try {
//            String query = "CREATE TABLE IF NOT EXISTS TABLE "+  tableName
//                    + " (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
//                    " prodid TEXT UNIQUE NOT NULL," +
//                    " title TEXT NOT NULL," +
//                    " cost INTEGER NOT NULL) VALUES (?, ?, ?, ?)";
//            PreparedStatement ps = connection.prepareStatement(query);
//            ps.setString(1, "id");
//            ps.setString(2, "prodid");
//            ps.setString(3, "title");
//            ps.setString(4, "cost");
//            ps.execute();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

}
