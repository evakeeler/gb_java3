package com.Level03.DZ_1;

import java.sql.*;
import java.util.Scanner;

import static com.Level03.DZ_1.CreateTable.connect;

public class MainController {
    private static Connection connection;
    private static Statement stmt;
    private static Scanner sc;

    public static void main(String[] args) {
        try {
            connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        clearTable("Products");
        fillTable("Products");
        console();

    }

    public static void fillTable(String tableName) {
        try {
            String query = "INSERT INTO " + tableName + "(id,prodid,title,cost)" +
                    " VALUES(?,?,?,?);";
            PreparedStatement ps = CreateTable.connection.prepareStatement(query);
            CreateTable.connection.setAutoCommit(false);
            for (int i = 0; i < 10000; i++) {
                ps.setInt(1, i + 1);
                ps.setInt(2, i + 1);
                ps.setString(3, "товар" + (i + 1));
                ps.setInt(4, (i + 1) * 10);
                ps.addBatch();
            }
            ps.executeBatch();
            CreateTable.connection.setAutoCommit(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void clearTable(String tableName) {
        try {
//            String query = "SELECT COUNT(*) FROM"+ tableName+";";
//            ResultSet rs = CreateTable.stmt.executeQuery(query);
//            if (rs.getInt(1)!=0){
            String query = "DELETE FROM " + tableName + "; VACUUM;";
            CreateTable.stmt.execute(query);
//            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void console() {
        new Thread(new Runnable() {
            public void run() {
                sc = new Scanner(System.in);
                String str;
                while (true) {
                    str = sc.nextLine();
                    if (str.startsWith("/выход")) {
                        break;
                    }
                    if (str.startsWith("/цена")) {
                        String[] tokens = str.split(" ");
                        String query = "SELECT cost FROM Products WHERE " +
                                "title = '" + tokens[1] + "';";
                        try {
                            ResultSet rs = CreateTable.stmt.executeQuery(query);
                            if (rs.next()) {
                                System.out.println(rs.getString(1));
                            } else {
                                System.out.println("Такого товара нет");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                    }

                    if (str.startsWith("/сменитьцену")) {
                        String[] tokens = str.split(" ");
                        String query = "SELECT cost FROM Products WHERE title = '" + tokens[1] + "';";
                        try {
                            ResultSet rs = CreateTable.stmt.executeQuery(query);
                            if (rs.next()) {
                                query = "UPDATE Products SET cost = " + tokens[2] + " WHERE title = '" + tokens[1] + "';";
                                try {
                                    CreateTable.stmt.executeUpdate(query);
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                System.out.println("Такого товара нет в таблице");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }

                    if (str.startsWith("/товарыпоцене")) {
                        String[] tokens = str.split(" ");
                        String query = "SELECT title FROM Products WHERE cost BETWEEN " + tokens[1] + " AND "+tokens[2]+";";
                        try {
                            ResultSet rs = CreateTable.stmt.executeQuery(query);
                            boolean empty = true;
                            while( rs.next() ) {
                                System.out.println(rs.getString("title"));
                                empty = false;
                            }
                            if( empty ) {
                                System.out.println("В заданном диапозоне нет товаров");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }

                }
                try {
                    CreateTable.connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

        }).start();
    }

}
